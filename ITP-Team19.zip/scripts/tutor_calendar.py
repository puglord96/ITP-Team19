
calendar_upcomings = [
    {
        'todo': "Consultation",
        'date': '2021-06-06T16:00:00',
        'zoom_link': 'trial.com'
    },
    {
        'todo': "Essay Writing",
        'date': '2021-06-07',
        'zoom_link': 'trial.com2'
    },
]

calendar_requests = [
    {
        'todo': "Consultation",
        'date' : '2021-06-08',
        'zoom_link': 'trial.com2'

    },
    {
        'todo': "Essay Writing",
        'date': '2021-06-09',
        'zoom_link': 'trial.com2'

    },
]