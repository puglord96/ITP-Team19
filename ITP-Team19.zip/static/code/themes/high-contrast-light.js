/*
 Highcharts JS v7.2.0 (2019-09-03)

 (c) 2009-2019 Highsoft AS

 License: www.highcharts.com/license
*/
(function(a){"object"===typeof module&&module.exports?(a["default"]=a,module.exports=a):"function"===typeof define&&define.amd?define("highcharts/themes/high-contrast-light",["highcharts"],function(b){a(b);a.Highcharts=b;return a}):a("undefined"!==typeof Highcharts?Highcharts:void 0)})(function(a){function b(a,b,c,d){a.hasOwnProperty(b)||(a[b]=d.apply(null,c))}a=a?a._modules:{};b(a,"themes/high-contrast-light.js",[a["parts/Globals.js"]],function(a){a.theme={colors:"#5f98cf #434348 #49a65e #f45b5b #708090 #b68c51 #397550 #c0493d #4f4a7a #b381b3".split(" "),
navigator:{series:{color:"#5f98cf",lineColor:"#5f98cf"}}};a.setOptions(a.theme)});b(a,"masters/themes/high-contrast-light.src.js",[],function(){})});
//# sourceMappingURL=high-contrast-light.js.map